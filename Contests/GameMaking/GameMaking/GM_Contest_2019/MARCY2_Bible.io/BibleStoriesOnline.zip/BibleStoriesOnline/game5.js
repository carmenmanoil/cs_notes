
var players=[];
var arrowInterval;
var rockObstacles = [];
var arrowObstacles = [];
var arrowInterval = [];
var serverInterval = [];
var Game5 = module.exports = {

  startGame: function(io) {

    heartbeatInterval = [];
    rockObstacles = [];
    arrowObstacles = [];
    arrowInterval = [];
    serverInterval = [];
    arrowInterval.push(setInterval(makeArrow, 4000));
    serverInterval.push(setInterval(updateServer, 33));
    console.log("Coming from game5.js");

      for(let i = 0;i < 80;i++){
      rockObstacles[i] = new RockObstacle("rock",Math.floor(Math.random()*400) +100,Math.floor(Math.random()*2000) -2000,30);
      }

    function makeArrow() {
      for(let i = 0;i < 6;i++){
        arrowObstacles.push(new ArrowObstacle("arrow",Math.floor(Math.random()*400) +100,500,30,40));
      }
    }
    function updateServer() {
      for(let a = 0; a < arrowObstacles.length; a++) {
        arrowObstacles[a].update();
        if(arrowObstacles[a].y < -5000) {
          arrowObstacles.splice(a,6);
        }
      }
      if (typeof players !== 'undefined') {

        for(let p = 0; p < players.length; p++) {
          for(let r = 0; r < rockObstacles.length; r++) {

            if(collided(players[p],rockObstacles[r])){
              players[p].speed = 0.5;

              setTimeout(function(){try{players[p].speed = 1.5;} catch(err){}}, 1000);

              break;
            }
          }
          for(let a = 0; a < arrowObstacles.length; a++) {
            if(collided(players[p],arrowObstacles[a])){
              players[p].speed = 0;
              try{
                setTimeout(function(){try{players[p].speed = 1.5;} catch(err){}}, 500);
              } catch(err) {}

              break;
            }
          }

        }

      }
    }
    function collided(player, obstacle){
      let a = player.x - obstacle.x;
      let b = player.y - obstacle.y;
      let c = Math.sqrt(a*a + b*b);
      let r = player.r/2 + obstacle.r/2 -5;
      if(c < r) {
        return true;
      } else {
        return false;
      }

    }

  },
  runGame: function(socket, playerslist){
    players = playerslist;
    socket.on('newPlayer',
    function(data) {
      for(let i = 0; i < players.length; i++) {

        if(players[i].id ==data.id) {
          newPlayer(i, data.x, data.y, data.speed, data.r);
          break;
        }
      }
      socket.emit("newRocks", rockObstacles);
    });
    function newPlayer(i,x,y,speed,r) {
      players[i].x = x;
      players[i].y = y;
      players[i].speed = 1.5;
      players[i].r = r;
    }
    socket.on('updatePlayer' ,
    function(data) {
      for(let i = 0; i < players.length; i++) {
        if(players[i].id ==data.id) {
          if(data.dir == 1 && players[i].x > 100) {
            players[i].x -= players[i].speed;
          } else if(data.dir == 2 && players[i].x < 500 ) {
            players[i].x += players[i].speed;
          } else if(data.dir == 3) {
            players[i].y -= players[i].speed;
          } else if (data.dir == 4){
            players[i].y += players[i].speed;
          }
          break;
        }
      }


    });


    heartbeatInterval.push(setInterval(heartbeat, 33));
    function heartbeat() {
      let data = {
        players: players,
        arrows: arrowObstacles
      }
      socket.emit('heartbeat',data);
    }

  },
  closeListeners: function(socket) {

    socket.removeAllListeners("newPlayer");
    socket.removeAllListeners("updatePlayer");
    for(let i = 0; i < heartbeatInterval.length; i++) {
      clearInterval(heartbeatInterval[i]);
    }
    for(let x = 0; x < arrowInterval.length; x++){
      clearInterval(arrowInterval[x]);
    }
    for(let y = 0; y < serverInterval.length; y++){
      clearInterval(serverInterval[y]);
    }



  },
  scores: function() {
    return players;
  }


}











class Base{
  constructor(type,x,y,r){
    this.x = x;
    this.y = y;
    this.r = r;
    this.type = type;
}
  show(){
    if(this.type=="player") {
      stroke(0);
      fill(200,100,100);
      image(player,this.x,this.y,this.r,this.r);
    }
    if(this.type=="rock"){
    stroke(0);
    fill(200,100,100);
    image(rock,this.x,this.y,this.r,this.r);
    }
    if(this.type=="arrow"){
    image(bull,this.x,this.y,this.r,this.r2);
    }
}

}

class RockObstacle extends Base{
  constructor(type,x,y,r){
    super(type,x,y,r);
  }
}
class ArrowObstacle extends Base{
  constructor(type,x,y,r,r2){
    super(type,x,y,r);
    this.r2 = r2;
  }
  update(){
  this.y-=6;
  }
}

class G5Player extends Base{
  constructor(type,x,y,r,playerID,speed){
  super(type,x,y,r);
    this.id = playerID;
    this.speed = speed;

  }
  update(){
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.speed;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.speed;
    }
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.speed;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.speed;
    }
  }
}
