
var heartbeatInterval;
var createEnemiesInterval;
var moveEnemiesInterval;
var collisionInterval;
var enemies = [];
var players = [];
var Game4 = module.exports = {
	startGame: function(io){
		console.log("coming from game4");
		heartbeatInterval = setInterval(heartbeat, 40);
		createEnemiesInterval = setInterval(createEnemies, 500);
		moveEnemiesInterval = setInterval(moveEnemies, 40);
		collisionInterval = setInterval(collision, 20);
		function playerCollision(player,x, rad) {
			try{
			for (let i = 0; i < player.bullets.length; i++) {
				var deltaX = player.bullets[i][0] - x[0];
				var deltaY = player.bullets[i][1] - x[1];
				if (deltaX*deltaX + deltaY*deltaY < (25/2+rad/2)*(25/2+rad/2)) {
					player.bullets.splice(i, 1);
					return true;
				}
			} }  catch(err){}
			return false;
		}
		function collision() {
			var newEnemies = [];
			for (let i = 0; i < enemies.length; i++) {
				var collide = false;
				for (let j = 0; j < players.length; j++) {
					if (playerCollision(players[j],enemies[i].x, 50)) {
						collide = true;
						players[j].score++;
						heartbeat();
						break;
					}
				}
				if (!collide) {
					newEnemies.push(enemies[i]);
				}
			}
			enemies = [...newEnemies];
		}

		function heartbeat() {
			io.sockets.emit('players', players);
			io.sockets.emit('enemies', enemies);
		}

		function moveEnemies() {
			for (let i = 0; i < enemies.length; i++) {
				enemies[i].x[1]+=5;
				if (enemies[i].x[1] > 500) {
					enemies.splice(i, 1);
				}
			}
		}

		function createEnemies() {
			enemies.push(new Enemy([Math.floor(Math.random() * Math.floor(500)),0]));
		}

		function Enemy(x) {
			this.x = x;
		}
	},

	runGame: function(socket, playerslist) {
		players = playerslist;
		socket.on('newPlayer', function(data){
			for(let p = 0; p < players.length; p++) {
				if(players[p].id == data.id){
					updatePlayer(p, data.loc, data.bullets, data.score);
				}
			}
		});

		function updatePlayer(i, loc, bullets, score) {
			players[i].loc = loc;
			players[i].bullets = bullets;
			players[i].score = score;
		}

		socket.on('update', function(data){
		    for (let i = 0; i < players.length; i++) {
		    	if(socket.id == players[i].id) {
		        players[i].loc = data.loc;
	    			players[i].bullets = data.bullets;
	    			players[i].score = data.score;
	    			players[i].bto = data.bto;
	    			players[i].hasShot = data.hasShot;
		      }
		    }
	  	});
	},

	clearInterval: function() {
		clearInterval(heartbeatInterval);
		clearInterval(createEnemiesInterval);
		clearInterval(moveEnemiesInterval);
		clearInterval(collisionInterval);
	}
}
