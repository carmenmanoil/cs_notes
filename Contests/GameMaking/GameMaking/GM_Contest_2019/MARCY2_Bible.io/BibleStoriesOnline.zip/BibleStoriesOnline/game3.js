var players = [];
var heartbeatInterval;
var time;
var timeSub = [];
var Game2 = module.exports = {
      startGame: function(io) {
        console.log("Coming from game3.js");
        time = 170;
        heartbeatInterval = [];
        timeSub = [];
        timeSub.push(setInterval(function() {time--; io.sockets.emit('timer',time);}, 100));
    },
      runGame: function(socket, playerslist) {

        heartbeatInterval.push(setInterval(function() {socket.emit('heartbeat', players);},33));

        players = playerslist;

        socket.on('finalScore',
        function(data){
          try{
            for(let i = 0; i < players.length; i++) {
              if(players[i].id == data.id) {
                players[i].score = data.score;
                break;
              }
            }
          } catch(err) {}

        }
      );
    },
    closeListeners: function(socket) {
      socket.removeAllListeners("finalScore");
      for(let j = 0; j < timeSub.length; j++) {
        clearInterval(timeSub[j]);
      }
      for(let i = 0; i < heartbeatInterval.length; i++) {
        clearInterval(heartbeatInterval[i]);
      }
    },
    scores: function() {
      return players;
    }
  }
