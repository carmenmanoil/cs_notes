

class G1Player{
  constructor(x,y,r, score,id){
    this.x = x;
    this.y = y;
    this.r = r;
    this.score = score;
    this.id = id;
    socket.emit("newPlayer", {
      id: this.id,
      x: this.x,
      y: this.y,
    });
  }

  show() {
    noFill();
    rectMode(RADIUS);
    image(this.noah,this.x,this.y,this.r,this.r);
  }
  update() {
    if (keyIsDown(DOWN_ARROW)) {
      socket.emit('updatePlayer', {id: this.id, dir: 4});
    }
    if (keyIsDown(UP_ARROW)) {
      socket.emit('updatePlayer', {id: this.id, dir: 3});
    }
    if (keyIsDown(LEFT_ARROW)) {
      socket.emit('updatePlayer', {id: this.id, dir: 1});
    }
    if (keyIsDown(RIGHT_ARROW)) {
      socket.emit('updatePlayer', {id: this.id, dir: 2});
    }
  }
}

class Game1Public{

  constructor() {
    this.player;
    this.players = [];
    this.animals = [];
    this.aImgs = [];
    this.noah;
  }
  removeListeners() {
    socket.removeAllListeners("heartbeat");
  }

  showInstructions() {
    fill(255);
    background(100,200,100);
    textAlign(CENTER, CENTER);
    textSize(40);
    text('Use the arrow keys to move Noah and collect animals for the ark!', width/2, height/2);
  }
  update(players,animals) {

    this.players = players;
    this.animals = animals;
  }
  setup(id){
    imageMode(CORNER);
    this.players = [];
    this.animals = [];
    this.player = new G1Player(random(-300,300), random(-300,300), 10, 0, id);
    this.noah = loadImage('assets/Noah.png');
    this.aImgs[0] = loadImage('assets/anim0.png');
    this.aImgs[1] = loadImage('assets/anim1.png');
    this.aImgs[2] = loadImage('assets/anim2.png');

    socket.on('heartbeat',
    function(data) {
        this.update(data.players, data.animals);
    }.bind(this)
  );

}

draw(){

  background(100,150,100);
  if(typeof this.players!== undefined) {
    for(let i = 0; i < this.players.length; i++) {
      fill(255);
      textAlign(RIGHT);
      textSize(16);
      text(this.players[i].id + "........" + this.players[i].score, width - 40, 30 + i * 20);
      if(this.players[i].id == this.player.id) {
        this.player.x = this.players[i].x;
        this.player.y = this.players[i].y;
        break;
      }
    }
    if(typeof this.player !== undefined) {translate(width/2-this.player.x, height/2- this.player.y);}
  for(let p = 0; p < this.players.length; p++) {
    noFill();
    rectMode(RADIUS);
    image(this.noah, this.players[p].x,this.players[p].y,this.players[p].r,this.players[p].r);
  }

  //translate(width/2-this.player.x,height/2-this.player.y);

  fill(255);
  }
  if (typeof this.animals !== 'undefined') {
  for(let a = 0; a <this.animals.length; a++) {

    if(this.animals[a].img == 'pig'){

      image(this.aImgs[0], this.animals[a].x, this.animals[a].y, this.animals[a].r*2, this.animals[a].r*2);
    } else if (this.animals[a].img == 'cow') {
      image(this.aImgs[1], this.animals[a].x, this.animals[a].y, this.animals[a].r*2, this.animals[a].r*2);
    } else {
      image(this.aImgs[2], this.animals[a].x, this.animals[a].y, this.animals[a].r*2, this.animals[a].r*2);
    }
  }
  }

  if(typeof this.player !== undefined) {this.player.update();}

}
}
