class Bar {
//bar = new Bar(x, bottom y, width, length of grey bar,
// increment of increase when space is clicked (smaller number means bigger increment),
// speed of decrease (bigger number means faster rate),
// id is a variable added by you
// -(where the game(green) bar starts in relation to normal bar(can't be greater than length)) //MAKE H NEGATIVE

//added h in the constructor
  constructor(x, y, w, vary, diff, speed, id, h) {

    this.diff = diff;
    this.speed = speed;
    this.wins = false;
    this.x = x;
    this.y = y;

    this.w = w;
    this.bx = x;
    this.by = y - vary;
    this.bw = w;
    this.bh = y - this.by;
    this.score = 0;
    this.id = id;
    this.h = h //made it h instead of this.bh

  }


  lose() {
    if (this.h >= 0) {
      this.h = 0;
    }
  }

  win(win) {
    if (this.h <= -this.bh) {
      this.wins = true;
    }
    if (this.wins) {
      background(win);
      textSize(50);
      fill(255);
      textAlign(LEFT);
      text("Your score: " +(int)(this.score / 100), 100, 120);
    }
  }


  bT(game,boulder) {
    if (!this.wins) {
      background(game);
      fill(200);
      rectMode(CORNER);
      rect(this.bx, this.by, this.bw, this.bh);
      fill(100, 255, 0);
      rect(this.x, this.y, this.w, this.h);

      imageMode(CENTER);
      image(boulder,(this.h *windowWidth/400)  + windowWidth/2, windowHeight/2, windowWidth/2, windowWidth/2) ;
      imageMode(CORNER);
      this.h += this.speed;
      this.score += 10;
      textSize(40);
      textAlign(CENTER);
      fill(255);
      text((int)(this.score / 100), 180, 30);
    }
  }

  mash() {
    this.h = this.h - 150 / this.diff;
  }

}
class Game2Public {
  constructor() {
    this.bar =  new Bar(windowWidth - 200, windowHeight/2, windowWidth/20, 200, 25, 0.92, id,0);
    this.win = loadImage("assets/cavewin.png");
    this.game = loadImage("assets/cavegamee.png");
    this.boulder = loadImage("assets/boulder.png");
    this.finished = false;
    this.players = [];

  }
  showInstructions() {
    fill(255);
    background(200,100,100);
    textAlign(CENTER, CENTER);
    textSize(40);
    text("Mash the space bar to move the stone in front of Jesus's tomb!", width/2, height/2);
  }
    removeListeners() {
      socket.removeAllListeners("heartbeat");
    }
  setup(id) {

    this.bar =  new Bar(windowWidth - 200, windowHeight/2, windowWidth/20, 200, 25, 0.92, id,0);
    this.win = loadImage("assets/cavewin.png");
    this.game = loadImage("assets/cavegamee.png");
    this.boulder = loadImage("assets/boulder.png");
    this.finished = false;
    socket.on('heartbeat',
    function(data) {
      this.update(data);
    }.bind(this)
  );
  }
  update(players) {
    this.players = players;
  }
  draw() {
    clear();
    this.keyPressed();
    this.bar.bT(this.game,this.boulder);
    this.bar.win(this.win);
    this.bar.lose();

    if(this.bar.wins && !this.finished) {
      let player = {
        id: this.bar.id,
        score: this.bar.score
      };

      socket.emit('finalScore', player);
      this.finished = true;
    }

    for(let p = 0; p < this.players.length; p++) {
      fill(255);
        textAlign(RIGHT);
        textSize(16);
        text(this.players[p].id + "........" + (int)(this.players[p].score/100), width - 40, 30 + p * 20);
    }
  }
  keyPressed() {
    //32 means spacebar
    if (keyCode == 32) {
      this.bar.mash();
      keyCode = -1;
    }
  }



}
