var oceanleft;
var oceanright;
var playerImg;
var otherplayerImg
var bull;
var rock;
class Game5Public {
  constructor() {
    this.players = [];
    this.rockObstacles = [];
    this.arrowObstacles = [];

  }
  removeListeners() {
    socket.removeAllListeners("heartbeat");
    socket.removeAllListeners("newRocks");

  }
  setup(id) {

    this.player = new Player("player",300,200,40,id,1);
    this.players = [];
    this.rockObstacles = [];
    this.arrowObstacles = [];
    oceanleft = loadImage('/assets/oceanleft.png');
    oceanright = loadImage('/assets/oceanright.png');
    playerImg = loadImage('/assets/G5player.png');
    otherplayerImg = loadImage('/assets/G5otherplayer.png');
    bull = loadImage('/assets/bull.png');
    rock = loadImage('/assets/rock.png');
    socket.on('heartbeat',
    function(data) {
      this.heartbeatUpdate(data.players, data.arrows);
    }.bind(this)
  );
  socket.on('newRocks' ,function(data){
    for(let i = 0; i < data.length; i++){
      this.updateRocks(i, data[i].x, data[i].y, data[i].r);
    }
  }.bind(this));


}
heartbeatUpdate(players, arrowObstacles) {
  this.players = players;
  this.arrowObstacles = arrowObstacles;
}

updateRocks(i,x,y,r) {
  this.rockObstacles[i] = (new RockObstacle('rock', x, y, r ));
}
draw() {
  for(let p = 0; p < this.players.length; p++) {
    if(this.players[p].id == this.player.id) {
      this.player.x = this.players[p].x;
      this.player.y = this.players[p].y;
      break;
    }
  }
  push();
  translate(width/2-300, height/2-this.player.y);

  background(198,166,100);
  noStroke();
  imageMode(CORNER);
  image(oceanleft,-500,-5000,600,6000);
  image(oceanright,500,-5000,600,6000);
  imageMode(CENTER);

  for(let i = 0;i<this.rockObstacles.length;i++){
    noFill();
    image(rock,this.rockObstacles[i].x,this.rockObstacles[i].y,this.rockObstacles[i].r,this.rockObstacles[i].r);
  }



  for(let p = 0; p < this.players.length; p++) {
    noFill();
    if(this.players[p].id !== socket.id){
      image(otherplayerImg, this.players[p].x,this.players[p].y,this.players[p].r,this.players[p].r);
    }

  }
  this.player.show();
  this.player.update();

  for(let i = 0;i<this.arrowObstacles.length;i++){
    image(bull,this.arrowObstacles[i].x,this.arrowObstacles[i].y,this.arrowObstacles[i].r,this.arrowObstacles[i].r2);
  }
  pop();
  for(let i = 0; i < this.players.length; i++) {
    fill(255);
    textAlign(RIGHT);
    textSize(16);
    text(this.players[i].id + "........" + Math.floor(Math.abs(this.players[i].y -200)), width - 40, 30 + i * 20);

  }

}
showInstructions() {
  fill(255);
  background(100,100,200);
  textAlign(CENTER, CENTER);
  textSize(30);
  text('Use the arrow keys to dodge obstacles when running through the Red Sea!', width/2, height/2);
}

}
class Base{
  constructor(type,x,y,r){
    this.x = x;
    this.y = y;
    this.r = r;
    this.type = type;
  }
  show(){
    if(this.type=="player") {
      stroke(0);
      fill(200,100,100);
      image(playerImg,this.x,this.y,this.r,this.r);
    }

  }
  collided(obstacle){

    if((this.x < obstacle.x + obstacle.r) && (this.y < obstacle.y + obstacle.r) && (this.x+10>obstacle.x) && (this.y+10 > obstacle.y) && obstacle.r == 10){
      this.speed = 0.5;

    }
    else if((this.x < obstacle.x + obstacle.r) && (this.y < obstacle.y + obstacle.r) && (this.x+15>obstacle.x) && (this.y+20 > obstacle.y)){
      this.speed = 0.5;

    }
  }
}

class RockObstacle extends Base{
  constructor(type,x,y,r){
    super(type,x,y,r);
  }
}
class ArrowObstacle extends Base{
  constructor(type,x,y,r,r2){
    super(type,x,y,r);
    this.r2 = r2;
  }
  update(){
    this.y-=4;
  }
}

class Player extends Base{
  constructor(type,x,y,r,playerID,speed){
    super(type,x,y,r);
    this.id = playerID;
    this.speed = speed;
    socket.emit("newPlayer", {
      id: this.id,
      x: this.x,
      y: this.y,
      speed: this.speed,
      r: this.r
    });
  }
  update(){

    if (keyIsDown(DOWN_ARROW)) {
      socket.emit('updatePlayer', {id: this.id, dir: 4});

    }
    if (keyIsDown(UP_ARROW)) {
      socket.emit('updatePlayer', {id: this.id, dir: 3});

    }
    if (keyIsDown(LEFT_ARROW)) {
      socket.emit('updatePlayer', {id: this.id, dir: 1});
    }
    if (keyIsDown(RIGHT_ARROW)) {
      socket.emit('updatePlayer', {id: this.id, dir: 2});
    }
  }
}
