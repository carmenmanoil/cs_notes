/*
	Quick Fire round code
	Games:
	- Make the light: Move your mouse in a circle to create the universe
	- Seperate the sea: Stop the sea from falling on the jewish slaves with your mouse
	- Plant the seeds: plant seeds and kick the crows
*/
var stone;
var david;
var goliath;

class G4Player {
	constructor(loc) {
		this.loc = loc;
		this.score = 0;
		this.bullets = [];
		this.mvspeed = 7;

		this.bulletSpeed = 5*500/height;
		this.bulletRad = 25;
		this.bulletTimeOut = 20; //Frames till player can shoot again
		this.hasShot = false; //stops the payer from holding shoot
	}
	step() {
		var newBullets = [];
		for (let i = 0; i < this.bullets.length; i++) {
			this.bullets[i][1] -= this.bulletSpeed;
			if (this.bullets[i][1] < 0) {
				continue;
			}
			fill(0);
			image(stone, this.bullets[i][0]*width/500, this.bullets[i][1]*height/500, this.bulletRad, this.bulletRad);
			newBullets.push(this.bullets[i]);
		}
		this.bullets = [...newBullets];
	}

	move(inp) {
		this.loc -= inp[0]*this.mvspeed;
		this.loc += inp[1]*this.mvspeed;
		if (this.loc < 0) {
			this.loc += 500;
		}
		this.loc %= 500;
	}

	shoot(inp) {
		if (this.bullets.length > 6) {
			return;
		}
		if (inp && !this.hasShot){
			this.hasShot = true;
			if(this.bulletTimeOut <= 0) {
				this.bullets.push([this.loc, 400]);
				this.bulletTimeOut = 20;
			}
		} else {
			if (!inp){
				this.hasShot = false;
			}
		}
		this.bulletTimeOut--;
	}
}

class Enemy {
	constructor() {
		this.loc = [random(width), 0];
		this.rad = height*0.075;
	}
	step() {
		this.loc[1] += 2;
	}
}

class Game4Public{
	showInstructions() {
		fill(255);
		background(200,200,100);
		textAlign(CENTER, CENTER);
		textSize(20);
		text('Quick, as David, shoot the Goliaths with space bar and move with arrow keys!', width/2, height/2);
	}
	setup(id) {
		stone = loadImage('assets/stone.png');
		david = loadImage('assets/david.png');
		goliath = loadImage('assets/goliath.png');

		this.keyboard = new Input();
		this.players = new Map();
		this.enemies = [];
		this.temploc = 250;
		this.myID =  id;

		this.enemyFrequency = 40; //Frequency enemies appear on screen, edit to change difficulty

		this.data = {loc: this.temploc,
					 bullets: [],
					 score: 0,
					 bto: 20,
					 hasShot: false};
		socket.emit('newPlayer', this.data);

		socket.on('players', function(data) {this.updatePlayers(data)}.bind(this));
		socket.on('enemies', function(data) {this.updateEnemies(data)}.bind(this));
		socket.on('clientid', function(data) {this.clientid(data)}.bind(this));
	}

	updatePlayers(data) {
		for (var p in data) {
			if (!this.players.has(data[p].loc)) {
				this.players.set(data[p].id, new G4Player(0));
			}
			this.players.get(data[p].id).loc = data[p].loc;
			this.players.get(data[p].id).bullets = data[p].bullets;
			this.players.get(data[p].id).score = data[p].score;
			this.players.get(data[p].id).bulletTimeOut = data[p].bto;
			this.players.get(data[p].id).hasShot = data[p].hasShot;
		}
	}

	updateEnemies(data) {
		this.enemies = data;
	}

	clientid(data) {
		this.myID = data;
		this.players.set(data, new G4Player(this.temploc));
	}

	draw() {
		background(0,255,0);
		fill(0);
		line(0, height*4/5, width, height*4/5);
		for (let [k, player] of this.players) {
			fill(0,0,255);
			image(david, player.loc*width/500, height*4/5, height*0.06, height*0.06);
			player.step();
		}
		for (var i = 0; i < this.enemies.length; i++) {
			image(goliath, this.enemies[i].loc[0]*width/500, this.enemies[i].loc[1]*height/500, 70, 70);
		}

		fill(0,0,255);
		textSize(20);

		fill(0);
		this.updateUser();
	}

	updateUser() {
		if (this.players.has(this.myID)){
			var inp = this.keyboard.keyboardInp();
			text("Score: " + this.players.get(this.myID).score, 0, 20);
			this.players.get(this.myID).move([inp[0], inp[1]]);
			this.players.get(this.myID).shoot(inp[2]);
			this.data = {loc: this.players.get(this.myID).loc,
				 		 bullets: this.players.get(this.myID).bullets,
				 		 score: this.players.get(this.myID).score,
				 		 bto: this.players.get(this.myID).bulletTimeOut,
						 hasShot: this.players.get(this.myID).hasShot};
			socket.emit('update', this.data);
		}
	}
}

class Input {
	constructor() {}
	keyboardInp() {
		return [keyIsDown(LEFT_ARROW), keyIsDown(RIGHT_ARROW), keyIsDown(32)];
	}
}
