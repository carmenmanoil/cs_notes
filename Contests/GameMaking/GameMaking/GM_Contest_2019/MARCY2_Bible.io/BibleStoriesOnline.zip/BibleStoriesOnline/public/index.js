
var scoreboardList;
var files = [];
var id;
var gamenumber =4;
var scoreboard = false;
var instructions = false;

function preload() {
  pixelFont = loadFont('assets/alagard.ttf');

}
function setup() {
//Main setup
  //socket = io.connect('localhost:5000');
  //test
//  console.log("reconnected");
  var canvas = createCanvas(windowWidth,windowHeight);
  textFont(pixelFont);
  frameRate(60);
  //command for ngrok: 'ngrok http 3000'
  //socket = io.connect('http://422a9a36.ngrok.io');
  //socket = io.connect('https://lit-tor-67808.herokuapp.com/');
  //socket = io.connect('localhost:5000');
  socket = io.connect('bibleio.herokuapp.com');
  loadFiles();
socket.on('scoreboard',
function(data) {
  scoreboard = true;
  scoreboardList = data;
  files[gamenumber-1].removeListeners();
});
socket.on('gameOver',
function(data) {
  scoreboard = false;
  gamenumber = data;
  instructions = true;
  files[gamenumber-1].setup(id);
  setTimeout(beforeInstructions, 2000);
}
);

socket.on('clientid',
function(data) {
  id = data
  instructions = true;
  files[gamenumber-1].setup(id);
  setTimeout(beforeInstructions, 2000);
}
);


}

function draw() {


  if(scoreboard) {
    background(100,100,100);
    textAlign(CENTER, CENTER);
    textSize(40);
    text('SCOREBOARD', width/2, 40);
    for(let i = 0; i < scoreboardList.length; i++) {
        text(scoreboardList[i].id + "..." + scoreboardList[i].totalscore, width/2, (40 * i+1) + 80);
    }

  } else if(instructions){
      files[gamenumber-1].showInstructions();
  } else {

    try{
        files[gamenumber-1].draw();
    }catch(err) {
      console.log(err);
    }
  }


}

function loadFiles() {
  files[0] = new Game1Public();
  files[1] = new Game2Public();
  files[2] = new Game3Public();
  //files[4] = new Game4Public();
  files[3] = new Game5Public();
}

function beforeInstructions() {
    instructions = false;
}
function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}
