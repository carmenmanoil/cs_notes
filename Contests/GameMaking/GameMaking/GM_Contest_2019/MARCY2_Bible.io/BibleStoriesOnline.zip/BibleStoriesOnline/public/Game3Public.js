//Because working with text files in JS is the worst
var words = ['LORD', 'GOD', 'MAN', 'ISRAEL', 'PEOPLE', 'KING', 'SON', 'MEN', 'HOUSE', 'DAY', 'CHILDREN', 'LAND', 'THINGS', 'HAND', 'EARTH', 'SONS', 'JERUSALEM', 'CITY', 'JESUS', 'FATHER', 'NAME', 'HEART', 'DAYS', 'DAVID', 'MOSES', 'PLACE', 'TIME', 'JUDAH', 'WORD', 'EVIL', 'HEAVEN', 'BRETHREN', 'WORDS', 'FIRE', 'EGYPT', 'THING', 'LAW', 'FATHERS', 'LIFE', 'HANDS', 'EYES', 'FEAR', 'VOICE', 'CHRIST', 'PRIEST', 'SPIRIT', 'SERVANTS', 'SOUL', 'SERVANT', 'GLORY', 'PEACE', 'GOLD', 'MOUTH', 'DEATH', 'PRIESTS', 'CITIES', 'SWORD', 'SIN', 'FACE', 'WATER', 'SEA', 'LEFT', 'WORK', 'BLOOD', 'WIFE', 'FLESH', 'WOMAN', 'BROTHER', 'HEAD', 'YEAR', 'SIDE', 'END', 'RIGHT', 'KINGDOM', 'NATIONS', 'POWER', 'SIGHT', 'ALTAR', 'JACOB', 'KINGS', 'ENEMIES', 'CONGREGATION', 'BREAD', 'NIGHT', 'SILVER', 'WORLD', 'WISDOM', 'JUDGMENT', 'JEWS', 'MULTITUDE', 'LOVE', 'DAUGHTER', 'SAUL', 'REST', 'AARON', 'WILDERNESS', 'CHIEF', 'COVENANT', 'TABERNACLE', 'TEMPLE'];

class Game3Public{
  constructor() {
    this.total = 170; // Frames needed to finish game
    this.timer = 170; // Frames left
    this.currentWord = words[random(words.length)|0];
    this.currentLetter = 0;
    //avoids two letters going out at once
    this.framesTillNext = 3;
    this.id;
    this.score = 0;

    this.tower;
    this.players = [];
  }
  removeListeners() {
    socket.removeAllListeners("heartbeat");
    socket.removeAllListeners("timer");
  }
  setup(id) {
    this.id = id;
    this.score = 0;
    this.currentWord = words[random(words.length)|0];
    this.currentLetter = 0;
    this.total = 170;
    this.timer = 170;
    this.framesTillNext = 3;
    this.players = [];
    this.tower = loadImage('assets/towerPiece.png');
    socket.on('heartbeat',
    function(data) {
      this.update(data);
    }.bind(this)
  );
    socket.on('timer',
    function(data) {
      this.updateTime(data);
    }.bind(this)
  );
}
updateTime(timer) {
  this.timer = timer;
}
update(players) {
  this.players = players;
}
draw() {

  this.framesTillNext--;
  if (this.timer <= 0) {
    // end game here
    let player = {
      id: this.id,
      score: this.score
    };
    socket.emit('finalScore', player);
  }

  background(0,0,255);
  fill(0,100,0);
  rect(0, height*0.8, width, height);
  fill(139,69,19);
  let bh = 60; // Brick Height
  for (var i = 0; i < this.score; i++) {
    image(this.tower,width/2 - bh*3, height*0.8 - bh*(i+1), bh*6, bh);
  }

  //Draws timer
  fill(0);
  rect(0, 0, width, height*0.05);
  fill(0, 255, 0);
  rect(10, 5, (width-20)*(this.timer/this.total), height*0.05 - 10);

  fill(255,0,0);
  textSize(20);
  text("Score: " + this.score, 0, height*0.1);

  this.input();

  // Draws current word letter by letter

  let sbl = 60; // Space between letters
  let start = width*0.5 - this.currentWord.length*sbl*0.48;
  textSize(70);
  for (let i = 0; i < this.currentWord.length; i++) {
    fill(0);
    if (i == this.currentLetter) {
      fill(255, 255, 0);
    }
    if (this.currentWord[i] == 'I') {
      text(this.currentWord[i], start+sbl*(i+0.25), height*0.9);
    } else if (this.currentWord[i] == 'W') {
      text(this.currentWord[i], start+sbl*(i-0.2), height*0.9);
    } else {
      text(this.currentWord[i], start+sbl*i , height*0.9);
    }
  }

  for(let p = 0; p < this.players.length; p++) {
    fill(255);
    textAlign(RIGHT);
    textSize(16);
    text(this.players[p].id + "........" + (int)(this.players[p].score/100), width - 40, 30 + p * 20);
  }
}
input() {
  if (this.currentWord[this.currentLetter] == key.toUpperCase() && this.framesTillNext <= 0) {
    this.currentLetter ++;
    this.framesTillNext = 3;
  }

  if (this.currentLetter == this.currentWord.length) {
    this.currentWord = words[random(words.length)|0];
    this.currentLetter = 0;
    this.score++;
    
  }
  key = "";
}
showInstructions() {
  fill(255);
  background(200,100,200);
  textAlign(CENTER, CENTER);
  textSize(40);
  text('Type the words that appear on screen to build the Tower of Babel!', width/2, height/2);
}
}
