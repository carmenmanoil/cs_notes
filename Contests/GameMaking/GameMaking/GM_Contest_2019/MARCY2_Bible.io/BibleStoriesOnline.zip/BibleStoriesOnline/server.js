var express = require('express');
var app = express();
var server = app.listen(process.env.PORT || 5000);
var players = [];
var socket = require('socket.io');
var io = socket(server);
var games = [];
var sockets = [];

games[0] =  new require('./game1.js');
games[1] =  new require('./game2.js');
games[2] = new require('./game3.js');
//games[3] = new require('./game4.js');
games[3] = new require('./game5.js');
//games[2] = new require('./game3.js');
var gamenumber =4;
app.use(express.static('public'));
//console.log("My socket server is running");


setInterval(showScoreboard, 20000);

games[gamenumber-1].startGame(io);

function showScoreboard() {
  for(let j = 0; j < sockets.length; j++ ) {
    games[gamenumber-1].closeListeners(sockets[j]);
  }
  let newplayers = games[gamenumber-1].scores();
  if(typeof players !== undefined){
  for(let x = 0 ; x < players.length;x++) {
    for(let y = 0; y < newplayers.length; y++) {
      if(players[x].id == newplayers[y].id) {
        if(gamenumber == 4) {
          players[x].score = newplayers[y].y;
        } else {
            players[x].score = newplayers[y].score;
        }

        break;
      }
    }
  }


    //console.log(players);
    if(players.length > 1){

      if(gamenumber == 2 || gamenumber == 4){
        players = players.sort((a, b) => (a.score > b.score) ? 1 : -1);
      } else{
        players = players.sort((a, b) => (a.score > b.score) ? -1 : 1);
      }
    }


  }

  if(players.length !== 0){players[0].totalscore++; }

  io.sockets.emit('scoreboard', players);
  setTimeout(switchGame, 2000);
}
function switchGame() {

//for clearing all intervals
  // games[gamenumber-1].endGame();
  if(gamenumber < 4) { gamenumber++; }
  else { gamenumber = 1;}

  // game = new require('./game' + gamenumber +'.js');
  if(gamenumber== 3 || gamenumber == 4) {
    games[gamenumber-1].startGame(io);

  } else {
    games[gamenumber-1].startGame();

  }

  for(let i = 0; i < sockets.length; i++ ) {
    games[gamenumber-1].runGame(sockets[i], players);
  }

  for(let p = 0 ; p < players.length; p++) {
    players[p].score = 0;
    players[p].x = undefined;
    players[p].y = undefined;
  }
  io.sockets.emit("gameOver", gamenumber);
}


io.sockets.on('connection', newConnection);
function newConnection(socket){
  if(sockets.length > 6) {
    socket.disconnect();
  } else {


  io.to(socket.id).emit("clientid", socket.id);
  io.to(socket.id).emit("gameOver", gamenumber);
  let temp = new Player(socket.id,undefined , undefined, 0, 0);
  players.push(temp);
  sockets.push(socket);
  games[gamenumber-1].runGame(socket, players);

  socket.on('disconnect',
  function(data) {


    for(let i = 0; i < players.length; i++){
      if(socket.id == players[i].id){
        try{
          players.splice(i,1);
          break;
        }
        catch(err){
          console.log('err disconnecting');
        }
      }

    }
    for(let s = 0; s < sockets.length; s++) {
      if(socket.id == sockets[s].id) {
        sockets.splice(s, 1);
        break;
      }
    }

  });
}
}


class Player{
  constructor(id,x,y,score, totalscore) {
    this.id = id;
    this.x = x;
    this.y = y;
    this.score = score;
    this.totalscore = totalscore;
  }
}
