var players = [];

var Game2 = module.exports = {
    // endGame: function(socket) {
    //   socket.removeAllListeners();
    // },
      startGame: function() {
        heartbeatInterval = [];
        console.log("Coming from game2.js");
    },
      runGame: function(socket, playerslist) {
        heartbeatInterval.push(setInterval(function(){socket.emit('heartbeat', players);}, 33));

        players = playerslist;
        socket.on('finalScore',
        function(data){
          try{
            for(let i = 0; i < players.length; i++) {
              if(players[i].id == data.id) {
                players[i].score = data.score;
                break;
              }
            }
          } catch(err) {}

        }
      );
    },
    closeListeners: function(socket) {
      socket.removeAllListeners("finalScore");
      for(let i = 0; i < heartbeatInterval.length; i++) {
        clearInterval(heartbeatInterval[i]);
      }

    },
    scores: function() {
      for(let i = 0; i < players.length; i++ ) {
        if(players[i].score ==0) {
          players[i].score = 999;
        }
      }
      return players;
    }
  }
