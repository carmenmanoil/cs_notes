var animals= [];
var anim;

var players=[];

class Animal{

  constructor(x,y,r,playerID, img){
    this.x = x;
    this.y = y;
    this.r = r;
    this.lerpX;
    this.lerpY;
    this.id = playerID;
    this.img = img;
    this.collided = false;
  }


}


var Game1 = module.exports = {

  startGame: function() {
    heartbeatInterval = [];
    console.log("Coming from game1.js");
    for(let i = 0;i < 80;i++){
      if(i <= 5) {anim = 'pig'; }
      else if(i <= 30) {anim ='cow'; }
      else if(i <= 50) {anim = 'bunny'; }
      animals[i] = new Animal(Math.floor(Math.random()*2000) -2000, Math.floor(Math.random()*2000) -2000, 20,"", anim);
    }
  },
  runGame: function(socket, playerslist){

    players = playerslist;
    socket.on('newPlayer',
    function(data) {
      for(let i = 0; i < players.length; i++) {

        if(players[i].id ==data.id) {
          players[i].x = data.x;
          players[i].y = data.y;
          break;
        }
      }
    });
    socket.on('updatePlayer' ,
    function(data) {
      for(let i = 0; i < players.length; i++) {
        if(players[i].id ==data.id) {
          if(data.dir == 1) {
            players[i].x -=3;
          } else if(data.dir == 2) {
            players[i].x +=3;
          } else if(data.dir == 3) {
            players[i].y -=3;
          } else {
            players[i].y +=3;
          }
          break;
        }
      }


    });


    heartbeatInterval.push(setInterval(heartbeat, 33));
    function heartbeat() {

      if (typeof players !== 'undefined') {

        for(let j = 0; j < animals.length; j++) {
          for(let i = 0; i < players.length; i++) {
                try {
            if((players[i].x < animals[j].x + animals[j].r) && (players[i].y < animals[j].y + animals[j].r) && (players[i].x +50 >animals[j].x) && (players[i].y + 50 > animals[j].y)  && !animals[j].collided){ // removed && !animals[j].collided for testing

              animals.splice(j,1);


              players[i].score++;


            }
          } catch(err) {}
        }

        }
      }

      let data = {
        players: players,
        animals: animals
      }
      socket.emit('heartbeat',data);
    }

  },
  closeListeners: function(socket) {

    socket.removeAllListeners("newPlayer");
    socket.removeAllListeners("updatePlayer");
    for(let i = 0; i < heartbeatInterval.length; i++) {
      clearInterval(heartbeatInterval[i]);
    }


  },
  scores: function() {
    return players;
  }


}
